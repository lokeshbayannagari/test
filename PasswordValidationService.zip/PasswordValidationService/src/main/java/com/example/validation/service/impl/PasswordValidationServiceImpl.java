package com.example.validation.service.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.validation.dto.RequestDto;
import com.example.validation.dto.ResponseBody;
import com.example.validation.service.PasswordValidationService;

@Service
public class PasswordValidationServiceImpl implements PasswordValidationService {

	@Override
	public ResponseEntity<ResponseBody> validatePassword(RequestDto requestDetails) {
		
		//If  flow is reached here means all validations passed
		
		return ResponseEntity.ok(new ResponseBody("success", "Password validation is successfull."));
	}

}
