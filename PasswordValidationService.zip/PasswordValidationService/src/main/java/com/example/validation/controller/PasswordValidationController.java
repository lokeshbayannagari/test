package com.example.validation.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.validation.dto.RequestDto;
import com.example.validation.dto.ResponseBody;
import com.example.validation.service.PasswordValidationService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/validatePassword")
public class PasswordValidationController {

	
	
	@Autowired(required=true)
	private PasswordValidationService passwordValidationService;
	

	 @PostMapping
	 public ResponseEntity<ResponseBody> validatePassword(@Valid  @RequestBody RequestDto requestDetails )
	 {
		 log.info("PasswordValidationController::validatePassword()::ENTER ");
		 return passwordValidationService.validatePassword(requestDetails);
	 }
	 
}
