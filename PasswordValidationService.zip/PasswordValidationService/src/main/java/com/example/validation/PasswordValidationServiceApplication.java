package com.example.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordValidationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordValidationServiceApplication.class, args);
	}

}
