package com.example.validation.service;


import org.springframework.http.ResponseEntity;

import com.example.validation.dto.RequestDto;
import com.example.validation.dto.ResponseBody;

public interface PasswordValidationService {
	
	 public ResponseEntity<ResponseBody> validatePassword( RequestDto requestDetails );

}
